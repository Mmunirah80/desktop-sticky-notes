package com.stickynotes.view;

import com.stickynotes.model.NotesManager;
import com.stickynotes.model.NotesObserver;
import com.stickynotes.model.StickyNote;

import javax.swing.*;
import java.awt.*;

/**
 * View for Sticky Notes App.
 * Implements NotesObserver to update the UI.
 */
public class NotesView extends JPanel implements NotesObserver {
    private final DefaultListModel<StickyNote> listModel;  
    private final JList<StickyNote> notesList; 
    private final JButton addButton;
    private final JButton removeButton;// interaction
    private final JButton editButton;

    public NotesView() {
        listModel = new DefaultListModel<>();
        notesList = new JList<>(listModel);
        addButton = new JButton("Add");
        removeButton = new JButton("Remove");
        editButton = new JButton("Edit");

        setLayout(new BorderLayout());

        add(new JScrollPane(notesList), BorderLayout.CENTER);

        JPanel buttons = new JPanel();
        buttons.add(addButton);
        buttons.add(removeButton);
        buttons.add(editButton);
        add(buttons, BorderLayout.SOUTH);

        update(); // initial load
    }

    @Override
    public void update() {
        listModel.clear();
        for (StickyNote note : NotesManager.getInstance().getNotes()) // get the current list from the model
        {
            listModel.addElement(note); // Takes each note from the Model and puts it into the View’s JList.
        }
    }

    public JList<StickyNote> getNotesList() { return notesList; }
    public JButton getAddButton() { return addButton; }
    public JButton getRemoveButton() { return removeButton; }
    public JButton getEditButton() { return editButton; }
}
