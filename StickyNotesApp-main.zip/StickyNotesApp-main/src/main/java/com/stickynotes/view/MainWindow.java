package com.stickynotes.view;

import com.stickynotes.controller.NotesController;
import com.stickynotes.model.StickyNote;

import javax.swing.*;

/**
 * Main window for Sticky Notes App.
 */
public class MainWindow extends JFrame {
    public MainWindow() {
        setTitle("Sticky Notes");
        setSize(400, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        NotesView view = new NotesView();
        NotesController controller = new NotesController(view); 
        add(view);

        // Button actions
        view.getAddButton().addActionListener(e -> {
            String title = JOptionPane.showInputDialog("Enter title:");
            String body = JOptionPane.showInputDialog("Enter body:");
            if (title != null && body != null) {
                controller.addNote(title, body);
            }
        });

        view.getRemoveButton().addActionListener(e -> {
            StickyNote selected = view.getNotesList().getSelectedValue();
            if (selected != null) {
                controller.removeNote(selected);
            }
        });

        view.getEditButton().addActionListener(e -> {
            StickyNote selected = view.getNotesList().getSelectedValue();
            if (selected != null) {
                String newTitle = JOptionPane.showInputDialog("Edit title:", selected.getTitle());
                String newBody = JOptionPane.showInputDialog("Edit body:", selected.getBody());
                if (newTitle != null && newBody != null) {
                    controller.updateNote(selected, newTitle, newBody);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainWindow mainWindow = new MainWindow();
            mainWindow.setVisible(true);
        });
    }
}
