package com.stickynotes.controller;

import com.stickynotes.model.NotesManager;
import com.stickynotes.model.StickyNote;
import com.stickynotes.view.NotesView;

/**
 * Controller for Sticky Notes App.
 * Connects View and Model.
 */
public class NotesController {
    private final NotesManager notesManager; // model
    private final NotesView notesView; // view

    public NotesController(NotesView view) {
        this.notesManager = NotesManager.getInstance();
        this.notesView = view;
        notesManager.addObserver(notesView); 
    }

    /** Adds a new note */
    public void addNote(String title, String body) {
        StickyNote note = new StickyNote(title, body);
        notesManager.addNote(note);
    }

    /** Removes a note */
    public void removeNote(StickyNote note) {
        notesManager.removeNote(note);
    }

    /** Updates a note */
    public void updateNote(StickyNote oldNote, String title, String body) {
        StickyNote updatedNote = new StickyNote(title, body);
        notesManager.updateNote(oldNote, updatedNote);
    }
}
