package com.stickynotes.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages all sticky notes.
 * Implements Singleton and Observable design patterns.
 */ 

public class NotesManager { 
    private static NotesManager instance;

    private final List<StickyNote> notes;
    private final List<NotesObserver> observers;
    
    /** 
     * Representation Invariant (RI):
     * - notes list is never null
     * - observers list is never null
     * - all StickyNote objects in notes are non-null
     * 
     * Abstraction Function (AF):
     * - Represents a collection of StickyNotes that can be added, removed, updated,
     *   and searched, while notifying observers of changes.
     */

    private NotesManager() {
        notes = new ArrayList<>();
        observers = new ArrayList<>();
        checkRep();
    }

    /** Returns the singleton instance */
    public static NotesManager getInstance() {
        if (instance == null) {
            instance = new NotesManager();
        }
        return instance;
    }

    /** Adds an observer */
    public void addObserver(NotesObserver observer) {
        observers.add(observer);
    }

    /** Removes an observer */
    public void removeObserver(NotesObserver observer) {
        observers.remove(observer);
    }

    /** Notifies all observers */
    private void notifyObservers() {
        for (NotesObserver observer : observers) {
            observer.update();
        }
    }

    /** @return unmodifiable list of notes */
    public List<StickyNote> getNotes() {
        return Collections.unmodifiableList(notes);
    }

    /** Adds a new note */
    public void addNote(StickyNote note) {
        notes.add(note);
        notifyObservers();
        checkRep();
    }

    /** Removes a note */
    public void removeNote(StickyNote note) {
        notes.remove(note);
        notifyObservers();
        checkRep();
    }

    /** Updates a note */
    public void updateNote(StickyNote oldNote, StickyNote newNote) {
        int index = notes.indexOf(oldNote);
        if (index != -1)
        {
            notes.set(index, newNote);
            notifyObservers();
        }
        checkRep();
    }

    /** Checks the Representation Invariant */
    private void checkRep() {
        if (notes == null) throw new RuntimeException("Notes list is null");
        if (observers == null) throw new RuntimeException("Observers list is null");
        for (StickyNote note : notes) {
            if (note == null) throw new RuntimeException("Note in notes list is null");
        }
    }

    /**
     * Recursively searches for StickyNotes containing a keyword in title or body.
     * 
     * @param keyword the search keyword
     * @return a list of matching StickyNotes
     */
    public List<StickyNote> searchNotesRecursive(String keyword) {
        return searchRecursiveHelper(keyword, 0);
    }

    /** Helper method for recursive search */
    private List<StickyNote> searchRecursiveHelper(String keyword, int index) {
        if (index >= notes.size()) return new ArrayList<>(); // base case   

        List<StickyNote> rest = searchRecursiveHelper(keyword, index + 1);
        StickyNote current = notes.get(index);

        if (current.getTitle().contains(keyword) || current.getBody().contains(keyword)) {
            List<StickyNote> result = new ArrayList<>();
            result.add(current);
            result.addAll(rest);
            return result;
        } else {
            return rest;
        }
    }
}