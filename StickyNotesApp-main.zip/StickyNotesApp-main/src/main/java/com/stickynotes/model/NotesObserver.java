package com.stickynotes.model;

/**
 * Observer interface for the NotesManager.
 */
public interface NotesObserver {
    /** Called when notes are updated */
    void update();
}
