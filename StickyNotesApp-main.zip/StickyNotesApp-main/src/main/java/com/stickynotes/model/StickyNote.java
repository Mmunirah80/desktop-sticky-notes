package com.stickynotes.model;

/**
 * Represents a single sticky note.
 * Immutable: title and body cannot be changed after creation.
 *
 */


public final class StickyNote { 

    private final String title;
    private final String body; //final can not change after / no setter to change the value 
   /** Representation Invariant (RI):
    	 * - title and body are non-null
    	 *
    	 * Abstraction Function (AF):
    	 * - Represents a sticky note with a title and body content.
    	 */
    /**
     * Constructs a new StickyNote.
     * @param title The note's title; must be non-null
     * @param body The note's body; must be non-null
     * @throws IllegalArgumentException if title or body is null
     */
    public StickyNote(String title, String body) {
        if (title == null || body == null) {
            throw new IllegalArgumentException("Title and body must be non-null");
        }
        this.title = title;
        this.body = body;
        checkRep();
    }

    /** @return the note's title */
    public String getTitle() {
        return title;
    }

    /** @return the note's body */
    public String getBody() {
        return body;
    }

    /** Checks the Representation Invariant */
    private void checkRep() {
        if (title == null) throw new RuntimeException("Title is null");
        if (body == null) throw new RuntimeException("Body is null");
    }

    /** Equality is based on title and body */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof StickyNote)) return false;
        StickyNote other = (StickyNote) obj;
        return title.equals(other.title) && body.equals(other.body); //مقارنة للمحتوى 
    }

    /** Hash code consistent with equals() */
    @Override
    public int hashCode() {
        return title.hashCode() * 31 + body.hashCode();
    }

    @Override
    public String toString() {
        return "StickyNote[title=" + title + ", body=" + body + "]";
    }
}